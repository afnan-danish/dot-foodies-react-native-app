export const firebaseConfig = {
    apiKey: "AIzaSyBfoBLz9jRJSzeVImJzsGtPvbpwWi57HIQ",
    authDomain: "food-app-84e56.firebaseapp.com",
    databaseURL: "https://food-app-84e56.firebaseio.com",
    projectId: "food-app-84e56",
    storageBucket: "food-app-84e56.appspot.com",
    messagingSenderId: "247889898935",
    appId: "1:247889898935:web:3cd22ee24310b5813d0c32",
    measurementId: "G-14L58H59CP"
};