import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import storage from '@react-native-firebase/storage';
import * as firebase from 'firebase';


const LoadImage = async(props) => {
    const imageRef = firebase.storage().ref('category/'+props.url);
    const url = imageRef.getDownloadURL().then((url)=> {
        url
    });
    return (
        
        <Text>Hello</Text>
    )
}
export default LoadImage;