import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import storage from '@react-native-firebase/storage';
import * as firebase from 'firebase';


class ShowCategory extends React.Component {
  render() {
    return (
        <Text>Hello</Text>
    )
  }
}
export default ShowCategory;