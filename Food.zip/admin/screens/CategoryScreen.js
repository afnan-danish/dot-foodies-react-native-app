import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import Header from '../../components/Header'
import {TextInput, Button, List} from 'react-native-paper'
import ImagePickerExample from '../CustomImagePicker'
import{ ThemeContext } from '../../components/Context';
import storage from '@react-native-firebase/storage';
import * as firebase from 'firebase';
import auth from 'firebase/auth';
import LoadImage from '../LoadImage'
import { ScrollView } from 'react-native-gesture-handler';
import { Icon } from 'react-native-paper/lib/typescript/src/components/Avatar/Avatar';

//import fire

class CategoryScreen extends React.Component {
  static contextType = ThemeContext;
  state = {
    addNew: false,
    catName: "",
    catDesc: "",
    catImgUrl: null,
    data:[],
  }
  
  setFoodImage = (uri) => {
    this.setState({catImgUrl: uri});
  }
  getCurrentUser() {
    firebase.auth().onAuthStateChanged((user) => {
      if (user) {
        return user.uid
      }
    });
  }
  uploadImage = async() => {
    const image = this.state.catImgUrl
    //const user = this.getCurrentUser();
    const refImage = firebase.storage().ref('category/'+Date.now().toString());
    refImage.putString(image, 'data_url', {contentType:'image/jpg'}).then((status) => {
      refImage.getDownloadURL().then((url) =>{
        console.log('Image uploaded');
        //console.log(status.metadata.name)
        firebase.database().ref('category/').push().set({
          name: this.state.catName,
          desc: this.state.catDesc,
          url: url
        })
        this.resetData()
      })
    });

  }
  componentDidMount = () => {
    const items = firebase.database().ref('category/')
    items.on("value", dataSnapshot => {
      var tasks = [];
      dataSnapshot.forEach(child => {
        tasks.push({
          name: child.val().name,
          desc: child.val().desc,
          url: child.val().url,
          key: child.key
        })
      });
      this.setState({
        data: tasks
      });
    });
  }
  resetData = () => {
    this.setState({addNew: false})
    this.setState({catName: ""})
    this.setState({catDesc: ""})
    this.setState({catImgUrl: null})
  }
  render() {
    const { colors } = this.context;
    const mylist = this.state.data.map(item=>{
      //console.log(item.url)
      return (
        <List.Item key={item.key}
          title={item.name}
          description={item.desc}
          left={props => <Image {...props} style={{height: 50, width:50}} source={{ uri: item.url }} />}
        />
      )
    });

    return (
      <View style={{flex:1}}>
        <Header navigation={this.props.navigation} title={this.props.route.name} />
        <ScrollView showsVerticalScrollIndicator={true}>
          <Button mode="contained" style={this.state.addNew?{display:'none'}:{backgroundColor: colors.primary, marginVertical: 15, marginHorizontal: 10}} onPress={() => this.setState({addNew: true})}>
            Add New Category
          </Button>
          <View style={this.state.addNew?{padding:15}:{display:'none'}}> 
            <Icon name="close" />
            <TextInput
              label="Category Name"
              value={this.state.catName}
              onChangeText={(catName) => this.setState({catName:catName})}
              mode='outlined'
            />
            <TextInput
              label="Desciption"
              value={this.state.catDesc}
              onChangeText={(catDesc) => this.setState({catDesc:catDesc})}
              mode='outlined'
            />
              
            <ImagePickerExample onImagePicked={this.setFoodImage} />
            <Button mode="contained" style={{backgroundColor: colors.primary, marginVertical: 15,}} onPress={() => this.uploadImage()}>
              Add Category
            </Button>
          </View>
          <View>
            {mylist}
          </View>
        </ScrollView>
      </View>
    )}
  }
  
export default CategoryScreen;

const styles = StyleSheet.create({
  addNew: {
    padding: 15,
  },
})